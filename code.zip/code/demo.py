from ardrone import libardrone
import time

drone = libardrone.ARDrone()
#drone.reset()
drone.takeoff()
time.sleep(2)
drone.land()
time.sleep(3)
drone.halt()

