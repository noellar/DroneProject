import RPi.GPIO as GPIO
import time, math
from threading import Thread
import global_vars as glob
#import whitelist_mode_active, whitelist_found, pot_range_value, close_threads, open_threads

#GPIO pins for each component
GPIO_LED_GREEN = 16
GPIO_LED_RED = 21
GPIO_BUTTON = 20
GPIO_POT_CHARGE = 15
GPIO_POT_DISCHARGE = 14

#Configuration
WHITELIST_SEARCH_DURATION = 60 #seconds

pot_range_thread = None

def setup():
    #Refer to pins by their BCM numbering
    GPIO.setmode(GPIO.BCM)

    #outputs
    GPIO.setup(GPIO_LED_GREEN, GPIO.OUT)
    GPIO.setup(GPIO_LED_RED, GPIO.OUT)

    #inputs
    GPIO.setup(GPIO_BUTTON, GPIO.IN, pull_up_down=GPIO.PUD_UP)

    #event listeners
    GPIO.add_event_detect(GPIO_BUTTON, GPIO.FALLING, callback=whitelist_button_pressed, bouncetime=WHITELIST_SEARCH_DURATION*1000+5000)

    #polling
    glob.pot_range_thread = Thread(target = update_pot_range_value)
    glob.pot_range_thread.start()
    glob.open_threads.append(glob.pot_range_thread)

def cleanup():
    turn_off_red()
    turn_off_green()
    GPIO.cleanup()

def turn_on_green():
    GPIO.output(GPIO_LED_GREEN, True)

def turn_off_green():
    GPIO.output(GPIO_LED_GREEN, False)

def turn_on_red():
    GPIO.output(GPIO_LED_RED, True)

def turn_off_red():
    GPIO.output(GPIO_LED_RED, False)

#Led routine for when whitelist mode found a drone
def blink_success():
    turn_off_green()
    for i in range(5):
        turn_on_green()
        time.sleep(0.2)
        turn_off_green()
        time.sleep(0.2)
    turn_on_green()

#Led routine for when whitelist mode found no drones
def blink_failure():
    turn_off_red()
    for i in range(5):
        turn_on_red()
        time.sleep(0.2)
        turn_off_red()
        time.sleep(0.2)



# Discharge the capacitor, leaving it ready to start filling up
def discharge():
    GPIO.setup(GPIO_POT_CHARGE, GPIO.IN)
    GPIO.setup(GPIO_POT_DISCHARGE, GPIO.OUT)
    GPIO.output(GPIO_POT_DISCHARGE, False)
    time.sleep(0.1)

# Return the time taken (uS) for the voltage on the capacitor
# to count as a digital input HIGH
# which is 1.65V or higher
def charge_time():
    GPIO.setup(GPIO_POT_DISCHARGE, GPIO.IN)
    GPIO.setup(GPIO_POT_CHARGE, GPIO.OUT)
    GPIO.output(GPIO_POT_CHARGE, True)
    t1 = time.time()
    while not GPIO.input(GPIO_POT_DISCHARGE):
        pass

    t2 = time.time()
    return (t2 - t1) * 1000000

# Take an analog reading as the time taken to charge after
# first discharging the capacitor
def analog_read():
    discharge()
    t = charge_time()
    discharge()
    return t

# Convert the time taken to charge the cpacitor into a value (1,10]
def read_resistance():
    n=10 #average several measurements
    total = 0;
    for i in range(1, n):
        total = total + analog_read()
    t = total / float(n)

    #normalize
    t = int((t-335)/9) + 1 #220 Ohm pot
    #t = int((t-660)/360) + 1  #10k Ohm pot
    t = min(max(1, t), 10)

    return t


def whitelist_button_pressed(channel):
    #set flag for monitor loop
    #global whitelist_mode_active, whitelist_found
    glob.whitelist_mode_active = True
    glob.whitelist_found = False

    turn_on_red()

    print('button pressed')
    #monitor loop is scanning
    time.sleep(WHITELIST_SEARCH_DURATION)

    turn_off_red()
    if glob.whitelist_found:
        print("Whitelisting drone")
        blink_success()
    else:
        blink_failure()
        print("Whitelisting failed")

    glob.whitelist_found = False
    glob.whitelist_mode_active = False

def update_pot_range_value():
    #global pot_range_value
    #global close_threads
    while not glob.close_threads:
        #print("updating pot value")
        glob.pot_range_value = read_resistance()
        time.sleep(0.5)
