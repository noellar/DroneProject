SLEEP_TIME=(1.0/100.0)	# 10ms
PARROT_IP='192.168.1.1'
local_ip=''
net_interface='wlan0'
secondary_net_interface='wlan1'
#hypotetical
power_threshold=-65
fly_away_threshold=power_threshold-9

#IO
whitelist_mode_active=False
whitelist={}
whitelist_found=False
pot_range_value=10

#Sinchronization
close_threads=False
open_threads=[]
