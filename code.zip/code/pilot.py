from ardrone import libardrone 
from power_to_distance import *
import global_vars as glob
from time import sleep
import os


#get RSSI (received signal strength indication) for one network
def _get_sig_pwr(essid):
	global secondary_net_interface
	x=os.popen('iwlist '+secondary_net_interface+' scan | grep -A35 "ESSID:\\"'+essid+'"').read()
	y=x.index('Signal level=')
	y+=len('Signal level=')
	z=x[y:].index(' ')

        signal = x[y:y+z]
        #signal = signal[:signal.index('/')]
        #signal=(int(signal)/2)-100
	
	return int(signal)

#improve estimation of RSSI of given network by averaging three samples
def get_sig_pwr(essid):
	a=_get_sig_pwr(essid)
	sleep(.1)
	b=_get_sig_pwr(essid)
	sleep(.1)
	c=_get_sig_pwr(essid)
	return (a+b+c)/3

#Whenever the program takeover a parrot drone, it launches *pilot_routine* to fly it away.
def pilot_routine(essid):
	global fly_away_threshold
	sleep(2)
	print 'Pilot routine started	!!!	'
	drone = libardrone.ARDrone()
	
	#print 'x'
	#drone.restore()
	#print 'y'
	drone.set_speed(0.5)
	#drone.takeoff()
	#sleep(4)
	#drone.land()
	#sleep(4)
	drone.move_backward()
	sleep(0.5*float(glob.pot_range_value))
	drone.restore()
	drone.hover()
	sleep(1)
	#drone.takeoff()
	drone.halt()
	
	"""current=get_sig_pwr(essid)
	print current

	move_forward_lapse=1.5
	while current>=fly_away_threshold:
		drone.move_forward()
		sleep(move_forward_lapse)
		drone.hover()
		new=get_sig_pwr(essid)
		print new

		if new>current:
			drone.turn_left()
			sleep(2.6666)
			drone.hover()
			move_forward_lapse=3.0
		else:
			move_forward_lapse=1.5
		current=new
	drone.hover()
	drone.halt()"""

def main():
	"""while True:
		x=get_sig_pwr('unitn')
		print str(calculateDistance(x,2400))+' '+str(x)
		#print get_sig_pwr('unitn')
		sleep(.5)"""
	

if __name__ == "__main__":
    main()
