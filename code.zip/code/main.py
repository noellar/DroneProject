import time
import os

from monitor import *
import global_vars as glob
import hw
import signal
import sys
def signal_handler(signal, frame):
        glob.close_threads=True
        print("Closing open threads:"+str(len(glob.open_threads)))
        for t in glob.open_threads:
               t.join()
        print("Joining threads")
        hw.turn_off_green()
        hw.cleanup()
        sys.exit(0)

def check_if_nic_exists(nic_id):
	return int(os.popen('ifconfig -a | grep '+nic_id+' | wc -l').read())!=1

def config():
	#global net_interface,secondary_net_interface
        net_interface = glob.net_interface
        secondary_net_interface = glob.secondary_net_interface
        
	if check_if_nic_exists(net_interface):
		print net_interface+' NOT found!!'
		exit(-1)
	if check_if_nic_exists(secondary_net_interface):
		print secondary_net_interface+' NOT found!!'
		exit(-1)

	os.popen('echo 0 > /proc/sys/net/ipv4/ip_forward')	#disable ipv4 forwarding to be a _blackhole_
	#os.popen('service network-manager stop')	#stop nm or it will interfere with our operations
	#os.popen('service wicd stop')
	
	os.popen('ifconfig '+net_interface+' down')
        os.popen('ifconfig '+secondary_net_interface+' down')

	os.popen('ifconfig '+net_interface+' up')
	os.popen('ifconfig '+secondary_net_interface+' up')
	
def main():
	if os.geteuid() != 0:
		print 'This program must be run as root [RAW sockets, Kernel property settings, ifconfig ... ]' #using flag SOCK_RAW on syscall
		exit(-1)	

	config()
        hw.setup() #IO sensors and lights

        hw.turn_on_green()
        
	signal.signal(signal.SIGINT, signal_handler)
	
        global pot_range_value
        while True:
               	scan()
                time.sleep(SLEEP_TIME)

        """except AttributeError, e:
                print(e)
        except ValueError, e:
                print(e)
        finally:
                glob.close_threads=True
                print("Closing open threads:"+str(len(glob.open_threads)))
                for t in glob.open_threads:
                        t.join()
                print("Joining threads")
                hw.cleanup()"""

if __name__ == "__main__":
        main()
